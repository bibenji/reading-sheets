#include <stdio.h>

int main()
{
  printf("What a wonderful World!\n");
  return 0;
}
