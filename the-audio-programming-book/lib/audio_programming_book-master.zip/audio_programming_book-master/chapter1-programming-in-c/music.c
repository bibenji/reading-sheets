#include <stdio.h>

int main()
{
  printf("~~Cus I'm really on the south side~~\n");
  return 0;
}
