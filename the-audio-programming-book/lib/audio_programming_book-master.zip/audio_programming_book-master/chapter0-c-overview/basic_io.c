#include <stdio.h>

int main()
{
  int a,b,c;
  printf("\n Please enter a number: ");
  scanf("%d",&a);
  printf(" Please enter a second number: ");
  scanf("%d",&b);
  c=a+b;
  printf("%d + %d = %d \n", a,b,c);
  return 0;
}
