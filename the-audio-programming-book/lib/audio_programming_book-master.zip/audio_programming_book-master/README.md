# audio programming book

Programs from the audio programming book

http://mitpress.mit.edu/books/audio-programming-book

![book cover](http://rcdn-2.fishpond.com.au/0002/690/142/6769294/6.jpeg)
